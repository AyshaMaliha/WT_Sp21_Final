<?php

?>
<html>
	<head></head>
	<body>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1>Apointment Request Info</h1></center></legend>
		
		
			
			<h3 style="text-align:left;">Patient Name: Fahim Mahtab Ifsan</h3>
			<h3 style="text-align:left;">Patient ID: 3046</h3>
			<h3 style="text-align:left;">Doctor's Name: Dr. Farzana Sohael</h3>
			<h3 style="text-align:left;">Department: Gynocology</h3>
			<h3 style="text-align:left;">Day: Sunday</h3>
			<br>
				
				
			
			<button  onclick="document.location='Notification.php'" style="height: 40px; width: 200px; float: left"><b><h3>Forward to Assistant</h3></b> </button>
		</fieldset>	
		</body>
</html>