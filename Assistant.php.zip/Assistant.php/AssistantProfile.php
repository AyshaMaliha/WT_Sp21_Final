<html>
	<head></head>
	<body>
	<fieldset>
		<legend><h1><b>Assistant Profile</b></h1></legend>
		
	<table>
	
	<td>
	<img src="user.jpg" alt="User Pic" width="200" height="200">
	</td>
	<td>
	
	<h2>Noor A Aysha</h2>
	<h3>Assistant of Dr. Ali Asif,</h3>
	<h3>Popular Diagnostic.</h3>
	
	</td>
	
	</table>
	
	<h3>Contact Number: +880 ********** (From Database)</h3>
	<h3>Email: aysha*********@gmail.com (From Database)</h3>
	
	
	<button  onclick="document.location='AssistantChat.php'" style="height: 40px; width: 100px; float: left"><b><h3>Chat</h3></b> </button>
		
	</fieldset>
		
		
	</body>
</html>