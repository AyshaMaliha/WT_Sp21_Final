<html>
	<head></head>
	<body>
	<style>
body{
	background-color:rgb(255, 255, 204);
}
.login-div{
	border:2px solid ;
	margin:auto; rgb(50,50,50);
	width:50%;
	margin-top:10%;
	background-color:white;
}
.my-font{
	font-size:px;
	font-family:consolas;
}
.my-text-field{
	width:200px;
}
.btn-mine{
	background-color:blue;
	border:none;
	color:white;
}

</style>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1></h1></center></legend>
		<form action="" method="post">
		
			
			<center><h1>Popular Diagnostic Centre</h1>
			<center><h2>4.5&#9733;&#9733;&#9733;&#9733;&#9734;</h2>
			
			
			<br>
			<br><br><br>
			<button align="right" <h4 style="text-align:right;">Coordinator</h4></button>
			
			<br>
			<br>
			     <br>
			      <h4 style="text-align:left;"><a href="MD Muntanuz Zaman Jurat.php">MD Muntanuz Zaman Jurat</a></h5>
				 <h4 style="text-align:right;"><a href="Fahim Mahtab.php">Fahim Mahtab</a></h5>
				  <h4 style="text-align:left;">Coordinator</h5>
				  <h4 style="text-align:right;">Coordinator</h5><br>
				  
				<h5 style="text-align:left;">Location : J. U. MOAR, HOUSE # 21 Road 7, Dhaka 1230</h5>
				<h5 style="text-align:left;">Contact:+8801658974123</h5>
				<h5 style="text-align:left;">Mail:populardiagnostic@gmail.com</h5>
				
				
				<br>
				<h4 style="text-align:left;"><a href="FAQ.php">FAQ</a></h5>
			
			<b>
			
			
			
			
			
	
		</form>
		</fieldset>	
		</body>
</html>