<html>
	<head></head>
	<body>
	<br>
	<h1><b>Welcome to Hospital Hub!</b></h1></center><br>
	<body background='cover.jpg' align = "left">
	<!-- <img src="cover.jpg" alt="COver" width="1280" height="720" style="float:right"> -->
	<h2>Are you tired of all the hassle <br> just to get proper medical attention?</h2><br>
	<h2>Don't wait anymore and <br> get the proper assistance from <br> Hospital Hub RIGHT NOW!</h2><br>
	<button  onclick="document.location='Signup.php'" style="height: 50px; width: 200px; float: left"><b><h3>Sign Up</h3></b> </button><br><br><br>
	<h2>Already have an account?</h2><br>
	<button  onclick="document.location='Login.php'" style="height: 50px; width: 200px; float: left"><b><h3>Log In</h3></b> </button>

	</body>
</html>