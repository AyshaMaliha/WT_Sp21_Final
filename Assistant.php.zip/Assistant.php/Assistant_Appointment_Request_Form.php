<?php

?>
<html>
	<head></head>
	<body>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1>Hospital Hub</h1></center></legend>
		
		
			<center><h1>Apointment Request</h1></center>
			<h3 style="text-align:left;">Patient Name: Fahim Mahtab Ifsan</h3>
			<h3 style="text-align:left;">Patient ID: 3046</h3>
			<h3 style="text-align:left;">Doctor's Name: Dr. Farzana Sohael</h3>
			<h3 style="text-align:left;">Department: Gynocology</h3>
			<h3 style="text-align:left;">Day: Sunday</h3>
			<br>
				
				
			
			<button align="left" onclick="window.location.href='Assistant_Appointment_Confirm_Form.php'" style="height: 100px; width: 250px";><b><h2>Proceed</h2></b></button>
			<button align="right" onclick="window.location.href='Assistant_Home_Form.php'" style="height: 100px; width: 250px";><b><h2>Reject</h2></b></button>

		</fieldset>	
		</body>
</html>