<?php

?>
<html>
	<head></head>
	<body>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1>Hospital Hub</h1></center></legend>
		
		
			<center><h1>Notification</h1></center>
			<a href="Assistant_Appointment_Request_Form.php"><h3 style="text-align:left;">New Appointment: Fahim Mahtab Ifsan</h3></a>
			<h3 style="text-align:left;">New Notice: Server will go through maintainance..</h3>
			<br>
			<a href="Assistant_Home_Form.php">Back</a>

				
				
			
			

		</fieldset>	
		</body>
</html>