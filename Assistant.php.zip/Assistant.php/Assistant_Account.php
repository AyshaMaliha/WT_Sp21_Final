<?php

?>

<html>
	<head></head>
	<body>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1>Hospital Hub</h1></center></legend>
		
		
			<center><h1>Account</h1></center>
			
			<img align="center" src="Profile_images.php/profileImage.jpg" alt="" height="300px" width="250px">
			<h4 style="text-align:left;">Name: Noor A Aysha</h4>
			<h4 style="text-align:left;">ID: 4202</h4>
			<h4 style="text-align:left;">UserName: Aysha_Maliha</h4>
			<h4 style="text-align:left;">Email: ayshamaliha15@gmail.com</h4>
			<h4 style="text-align:left;">Phone: 01992012220</h4>
			<h4 style="text-align:left;">Gender: Female</h4>
			<h4 style="text-align:left;">Birth Date: 15 Jan, 1997</h4>
			
				
				
				
				
			
			
			<button align="left" onclick="window.location.href='Assistant_Profile_Edit_Form.php'" style="height: 100px; width: 250px";><b><h2>Edit</h2></b></button>
	
		
		</fieldset>	
		</body>
</html>