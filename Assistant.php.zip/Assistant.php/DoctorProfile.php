<html>
	<head></head>
	<body>
	<fieldset>
		<legend><h1><b>Doctor Profile</b></h1></legend>
		
	<table>
	
	<td>
	<img src="user.jpg" alt="User Pic" width="200" height="200">
	</td>
	<td>
	
	<h2>Dr. Ali Asif</h2>
	<h3>M.B.B.S.,Dhaka Medical College, Dhaka.</h3>
	<h3>Cardiology Specialist</h3>
	
	</td>
	
	</table>
	
	<h3>Available: YES/NO (From Database)</h3>
	<h3>Every Sunday to Thursday (From Database)</h3>
	<h3>From 09:00 A.M. TO 03:00 P.M. (From Database)</h3>
	
	<h1 style="text-align:right">Assistant</h3>
	<a href="AssistantProfile.php">
	<img align="right" src="user.jpg" alt="User pic" style="width:80px;height:80px;">
	</a>
	<br><br><br><br>
	<h3 style="text-align:right">Noor A Aysha</h3>
	
		
	</fieldset>
		
		
	</body>
</html>