<?php

?>
<html>
	<head></head>
	<body>
	    <fieldset style="width:1000px" align="center">
	    <legend align="center"><center><h1>Hospital Hub</h1></center></legend>
		
		
			<center><h1>Chat</h1></center>
			<a href="Assistant_Home_Form.php"><h3 style="text-align:left;">Md. Muntanuz Zaman Jurat</h3></a>
			<br>
			<a href="Assistant_Home_Form.php">Back</a>
				
				
			
			

		</fieldset>	
		</body>
</html>